package service;

import model.Employee;
import java.util.ArrayList;
import java.util.List;

public class PayrollService {

    private List<Employee> employees = new ArrayList<>();

    public void addEmployee(Employee emp) {
        employees.add(emp);
        System.out.println("Employee added successfully");
    }

    public void viewEmployees() {
        if (employees.isEmpty()) {
            System.out.println("No employees found");
            return;
        }

        for (Employee e : employees) {
            System.out.println(
                "ID: " + e.getId() +
                " Name: " + e.getName() +
                " Salary: " + e.getSalary()
            );
        }
    }

    public List<Employee> getEmployees() {
        return employees;
    }
}
