import model.Employee;
import service.PayrollService;
import util.FileUtil;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        PayrollService service = new PayrollService();

        FileUtil.loadEmployees(service.getEmployees());

        int choice;

        do {
            System.out.println("\n--- Employee Payroll System ---");
            System.out.println("1. Add Employee");
            System.out.println("2. View Employees");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Employee ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter Salary: ");
                    double salary = sc.nextDouble();

                    service.addEmployee(new Employee(id, name, salary));
                    break;

                case 2:
                    service.viewEmployees();
                    break;

                case 3:
                    FileUtil.saveEmployees(service.getEmployees());
                    System.out.println("Exiting Payroll System...");
                    break;

                default:
                    System.out.println("Invalid choice");
            }

        } while (choice != 3);
    }
}
